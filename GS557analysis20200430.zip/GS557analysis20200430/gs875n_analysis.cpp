﻿#include "widget.h"
#include <QtWidgets>
#include "my_string.h"
#include <string.h>
#include <QTextCodec>
#include <QString>

typedef unsigned char               u8;
typedef unsigned short              u16;
typedef unsigned int                u32;
typedef signed char                 s8;
typedef signed short                s16;
typedef signed int                  s32;

void Widget::textedit_handle_GS875Ndata(void){
    if(module_type_index == 1)
    {
        unsigned char PrintChinses = 1;
//        if(ChinesePrintBox->isChecked())
//        {
//            PrintChinses = 1;
//        }
        QByteArray data;
        QString display;
        unsigned short length = 0,length1 =0;

        textedit->clear();
        char result = 0;
//        unsigned char tempLength = 0;
        char* pdata1 = lineEdit->text().toLocal8Bit().data();
        unsigned char* pdata = (unsigned char*)pdata1;
        unsigned char buff[256] = {0};

        unsigned char out[2048] = {0};
        unsigned char *p = out;
        unsigned char *pbuff = buff;
        if(strlen((char*)pdata) > 0)
        {
            result = str2hex(buff,pdata,strlen((char*)pdata));//60  //0x12  0x01 0x02
            if(result)
                textedit->setText("输入待解析的数据长度不为偶数！！");
            else{
                    if(uploadCheckBox->isChecked())//解析上传到平台的数据
                    {
                        length1 = strlen((char*)pdata) / 2 - 2;
                        length = static_cast<unsigned short>(*(pbuff++) << 8);
                        length |= *(pbuff++);
                        if(length1 != length)
                        {
                           display.append("The length of Input data is ERROR\r\n");
//                           textedit->setText("The length of Input data is ERROR！！");
                        }
                        else
                        {
                            display.append("Length:" + QString::number(length, 10));

                            unsigned char option;
                            option = *(pbuff++);
                            display.append("\r\nOption:0x" + QString::number(option, 16));

                            unsigned short serial;
                            serial = static_cast<unsigned short>(*(pbuff++) << 8);
                            serial |= *(pbuff++);
                            display.append("\r\nSerial:" + QString::number(serial, 10));

                            unsigned short command;
                            command = static_cast<unsigned short>(*(pbuff++) << 8);
                            command |= *(pbuff++);
                            display.append("\r\nCommand:0x" + QString::number(command, 16)+"(hex)");

                            if(command == 0x1400) //设备信息包
                            {
                                QByteArray manufacturer;
                                manufacturer.append(*(pbuff++));
                                manufacturer.append(*(pbuff++));
                                display.append("\r\nManufacturer:" + QString(manufacturer));

                                unsigned char deviceType;
                                deviceType = *(pbuff++);
                                display.append("\r\nDeviceType:" + QString::number(deviceType, 10));

                                unsigned char SD_HwVersion;
                                SD_HwVersion = *(pbuff++);
                                display.append("\r\nSD_HwVersion:" + QString::number(SD_HwVersion, 16));

                                unsigned char SD_SwVersion;
                                SD_SwVersion = *(pbuff++);
                                display.append("\r\nSD_SwVersion:" + QString::number(SD_SwVersion, 16));

                                unsigned char SM_PtVersion;
                                SM_PtVersion = *(pbuff++);
                                display.append("\r\nSM_PtVersion:" + QString::number(SM_PtVersion, 16));
//0051000000140053570111111101310131383639393736303332353034313233383639393736303332353034313233383639393736303332353034313233343536373800010001

                                unsigned char MD_FwVersion_Length;
                                QByteArray MD_FwVersion;
                                MD_FwVersion_Length = *(pbuff++);
                                if(MD_FwVersion_Length > 0)
                                {
                                    MD_FwVersion.append((char*)pbuff, MD_FwVersion_Length);
                                    display.append("\r\nMD_FwVersion:" + MD_FwVersion);
                                    pbuff += MD_FwVersion_Length;
                                }
                                else
                                {
                                    display.append("\r\nMD_FwVersion:null");
                                }

                                unsigned char APP_SwVersion_Length;
                                QByteArray APP_SwVersion;
                                APP_SwVersion_Length = *(pbuff++);
                                if(APP_SwVersion_Length > 0)
                                {
                                    APP_SwVersion.append((char*)pbuff, APP_SwVersion_Length);
                                    display.append("\r\nAPP_SwVersion:" + APP_SwVersion);
                                    pbuff += APP_SwVersion_Length;
                                }
                                else
                                {
                                    display.append("\r\nAPP_SwVersion:null");
                                }

                                display.append("\r\nIMEI:" + QByteArray((char*)pbuff, 15));
                                pbuff += 15;

                                display.append("\r\nIMSI:" + QByteArray((char*)pbuff, 15));
                                pbuff += 15;

                                display.append("\r\nICCID:" + QByteArray((char*)pbuff, 20));
                                pbuff += 20;


                                unsigned char ActiveTime_Flag = *(pbuff++);
                                QByteArray ActiveTime;
                                if(ActiveTime_Flag == 0x00)
                                {
                                    QString ActiveTimeStr = decToBin(*(pbuff++));
                                    display.append("\r\nActiveTime:" + ActiveTimeStr + "(binary)");
                                }
                                else
                                {
                                    pbuff++;
                                    display.append("\r\nActiveTime:invalid");
                                }

                                unsigned char tauFlag;
                                tauFlag = *(pbuff++);
                                if(tauFlag == 0x00)
                                {
                                    QString str = decToBin(*(pbuff++));
                                    display.append("\r\nTAU:" + str + "(binary)");
                                }
                                else
                                {
                                    pbuff++;
                                    display.append("\r\nTAU:invalid");
                                }

                            }
                            else if(command == 0x1401) //状态/心跳包
                            {
                                unsigned char Public_Status1 = 0;
                                unsigned char Public_Status2 = 0;
                                unsigned char Gas_Status1 = 0;
                                Public_Status1 = pbuff[0];
                                Public_Status2 |= pbuff[1];
                                QString str1 = decToBin(*(pbuff++));
                                QString str2 = decToBin(*(pbuff++));
                                str1.append(str2);
                                display.append("\r\nPublic_Status:" + str1 + "(binary)");
                                if(Public_Status1&0x01){
                                    display.append("\r\n通信模块和mcu通信异常");
                                }
                                else if(Public_Status2&0x80){
                                    display.append("\r\n拆卸报警");
                                }
                                if(Public_Status2&0x40){
                                    display.append("\r\n蜂鸣器故障");
                                }
                                if(Public_Status2&0x20){
                                    display.append("\r\n寿命终止");
                                }
                                if(Public_Status2&0x10){
                                    display.append("\r\n低压");
                                }
                                if(Public_Status2&0x08){
                                    display.append("\r\n低压免打扰");
                                }
                                if(Public_Status2&0x02){
                                    display.append("\r\n本地报警测试");
                                }
                                if(Public_Status2&0x01){
                                    display.append("\r\n心跳包");
                                }

                                Gas_Status1 = *buff;
                                QString Gas_Status = decToBin(*(pbuff++));
                                display.append("\r\nGas _Status:" + Gas_Status);

                                if(Gas_Status1&0x01){
                                    display.append("\r\nGAS传感器故障免打扰");
                                }
                                if(Gas_Status1&0x02){
                                    display.append("\r\nGAS传感器故障");
                                }
                                if(Gas_Status1&0x04){
                                    display.append("\r\nGAS报警静音");
                                }
                                if(Gas_Status1&0x08){
                                    display.append("\r\nGAS报警");
                                }

                                Gas_Status1 = *buff;
                                QString Co_Status = decToBin(*(pbuff++));
                                display.append("\r\nCo_Status:" + Co_Status);

                                if(Gas_Status1&0x01){
                                    display.append("\r\nCO传感器故障免打扰");
                                }
                                if(Gas_Status1&0x02){
                                    display.append("\r\nCO传感器故障");
                                }
                                if(Gas_Status1&0x04){
                                    display.append("\r\nCO报警静音");
                                }
                                if(Gas_Status1&0x08){
                                    display.append("\r\nCO报警");
                                }


                                unsigned char GasLevel;
                                GasLevel = *(pbuff++);
                                display.append("\r\nGasLevel:" + QString::number(GasLevel, 10)+"%");

                                unsigned short CoLevel;
                                CoLevel = static_cast<unsigned short>(*(pbuff++) << 8);
                                CoLevel |= *(pbuff++);
                                display.append("\r\nCoLevel:" + QString::number(CoLevel, 10)+"(ppm)");

                                unsigned char Battery_Level;
                                Battery_Level = *(pbuff++);
                                display.append("\r\nBattery_Level:" + QString::number(Battery_Level, 10)+"%");

                                unsigned char CSQ;
                                CSQ = *(pbuff++);
                                display.append("\r\nCSQ:" + QString::number(CSQ, 10));

                                unsigned char ECL;
                                ECL = *(pbuff++);
                                display.append("\r\nECL:" + QString::number(ECL, 10));

                                short SNR;
                                SNR = static_cast<unsigned short>(*(pbuff++) << 8);
                                SNR |= *(pbuff++);
                                display.append("\r\nSNR:" + QString::number(SNR, 10)+"(DB)");

                                unsigned short pci;
                                pci = static_cast<unsigned short>(*(pbuff++) << 8);
                                pci |= *(pbuff++);
                                display.append("\r\nPCI:" + QString::number(pci, 10));

                                short rsrp;
                                rsrp = static_cast<unsigned short>(*(pbuff++) << 8);
                                rsrp |= *(pbuff++);
                                display.append("\r\nRSRP:" + QString::number(rsrp, 10));

                                short rsrq;
                                rsrq = static_cast<unsigned short>(*(pbuff++) << 8);
                                rsrq |= *(pbuff++);
                                display.append("\r\nRSRQ:" + QString::number(rsrq, 10));

                                unsigned short earfcn;
                                earfcn = static_cast<unsigned short>(*(pbuff++) << 8);
                                earfcn |= *(pbuff++);
                                display.append("\r\nEARFCN:" + QString::number(earfcn, 10));

                                unsigned int cellid;
                                cellid = static_cast<unsigned int>(*(pbuff++) << 24);
                                cellid |= static_cast<unsigned int>(*(pbuff++) << 16);
                                cellid |= static_cast<unsigned int>(*(pbuff++) <<  8);
                                cellid |= static_cast<unsigned int>(*(pbuff++));
                                display.append("\r\nCellID:" + QString::number(cellid, 10));

                            }
                            else if(command == 0x1402) //状态/心跳包
                            {
                                unsigned char Mute_Cmd;
                                Mute_Cmd = *(pbuff++);
                                display.append("\r\nMute_Cmd:" + QString::number(Mute_Cmd, 16));
                            }
                            else if(command == 0x1403) //状态/心跳包
                            {
                                unsigned char Mute_Cmd_Resp;
                                Mute_Cmd_Resp = *(pbuff++);
                                display.append("\r\nMute_Cmd:" + QString::number(Mute_Cmd_Resp, 16));
                            }
                            else//非法数据
                            {
                                QMessageBox::warning(this, tr("hint"), "No valid command was found", "OK");
                            }
                        }
                        textedit->insertPlainText(display);
                    }

                    if(floorCheckBox->isChecked())//解析底板上传的数据
                    {
                        //硬件版本
                        //FF551501 01
                        //包长度
                        unsigned char datalength = 0;
                        datalength = pbuff[2];

                        length = distextDirect(p, "Package length ：");
                        p += length;
                        length = DEC2DecStru32(p,pbuff[2]);
                        p += length;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");

                        length = distextDirect(p, "Package Serial ：");
                        p += length;
                        length = DEC2DecStru32(p,pbuff[3]);
                        p += length;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");

                        pbuff += 4;
                        while(*pbuff)
                        {
                            float_t vdd = 0;
                            u16 Battery = 0;
                            unsigned short Co_Sensor_Current_Level;
                            unsigned short Co_Sensor_Current_Leve_AD;
                            unsigned short Gas_Sensor_Current_Level;
                            unsigned short Gas_Sensor_Current_Level_AD;
                            unsigned short Current_Environment_Light_AD;
                            switch (*pbuff)
                            {
                            case 0x01:
                                length =  distext(p, "Reply success");
                                p += length;
                                pbuff += 1;//命令没有参数
                                break;
                            case 0x05://1字节
                                length =  distextDirect(p, "hardware version:");
                                p += length;
                                DEC2Str(p,pbuff[1]);
                                p += 2;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");
                                pbuff += 2;//命令加1参数
                                break;
                            case 0x0F://5字节
                                length = distextDirect(p, "Public_Status:");
                                p += length;
                                length = Hex2BinaryStr(p,pbuff[3]);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");
                                if(pbuff[3]&0x80){
//                                    length =  distext(p, "anti_temper Alarm");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "拆卸报警");
                                    p += length;}
                                }
                                if(pbuff[3]&0x40){
//                                    length =  distext(p, "Buzzer Fault");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "蜂鸣器故障");
                                    p += length;}
                                }
                                if(pbuff[3]&0x20){
//                                    length =  distext(p, "Life End");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "寿命终止");
                                    p += length;}
                                }
                                if(pbuff[3]&0x10){
//                                    length =  distext(p, "Low Voltage Warning");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "低压");
                                    p += length;}
                                }
                                if(pbuff[3]&0x08){
//                                    length =  distext(p, "Low Voltage Warning No Disturbing");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "低压免打扰");
                                    p += length;}
                                }
                                if(pbuff[3]&0x04){
//                                    length =  distext(p, "RF Test");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "远程RF测试");
                                    p += length;}
                                }
                                if(pbuff[3]&0x02){
//                                    length =  distext(p, "Key Test");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "本地报警测试");
                                    p += length;}
                                }
                                if(pbuff[3]&0x01){
//                                    length =  distext(p, "Heart Beat");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "心跳包");
                                    p += length;}
                                }

                                length = distextDirect(p, "Gas_Co_Status:");
                                p += length;
                                length = Hex2BinaryStr(p,pbuff[5]);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");

                                if(pbuff[5]&0x80){
//                                    length =  distext(p, "GAS Warning");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "GAS预警");
                                    p += length;}
                                }
                                if(pbuff[5]&0x40){
//                                    length =  distext(p, "CO Alarm");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "CO报警");
                                    p += length;}
                                }
                                if(pbuff[5]&0x20){
//                                    length =  distext(p, "GAS Alarm Mute");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "GAS报警静音");
                                    p += length;}
                                }
                                if(pbuff[5]&0x10){
//                                    length =  distext(p, "CO Alarm Mute");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "CO报警静音");
                                    p += length;}
                                }
                                if(pbuff[5]&0x08){
//                                    length =  distext(p, "GAS Sensor Fault");
//                                    p += length;
                                    if(PrintChinses){
                                    length =  distext(p, "GAS传感器故障");
                                    p += length;}
                                }
                                pbuff += 6;//命令加5参数
                            break;

                            case 0x11://6字节

                                Battery = pbuff[2];
                                Battery = (Battery<<8)|pbuff[3];
                                vdd = ((3.3*Battery*20) / 409.6);//放大100

                                if(vdd>400){
                                    Battery = 100;
                                  }
                                  else if(vdd>395){
                                    Battery = 95;
                                  }
                                  else if(vdd>390){
                                    Battery = 90;
                                  }
                                  else if(vdd>387){
                                    Battery = 85;
                                  }
                                  else if(vdd>384){
                                    Battery = 80;
                                  }
                                  else if(vdd>382){
                                    Battery = 75;
                                  }
                                  else if(vdd>379){
                                    Battery = 70;
                                  }
                                  else if(vdd>377){
                                    Battery = 65;
                                  }
                                  else if(vdd>374){
                                    Battery = 60;
                                  }
                                  else if(vdd>373){
                                    Battery = 55;
                                  }
                                  else if(vdd>371){
                                    Battery = 50;
                                  }
                                  else if(vdd>370){
                                    Battery = 45;
                                  }
                                  else if(vdd>369){
                                    Battery = 40;
                                  }
                                  else if(vdd>364){
                                    Battery = 30;
                                  }
                                  else if(vdd>359){
                                    Battery = 20;
                                  }
                                  else if(vdd>349){
                                    Battery = 15;
                                  }
                                  else if(vdd>324){
                                    Battery = 10;
                                  }
                                  else if(vdd>315){
                                    Battery = 5;
                                  }
                                  else{
                                    Battery = 0;
                                  }
                                strcpy((char*)p,"Battery Level：");// 3.3*AD*2 / 4096
                                p += strlen("Battery Level：");
                                length = DEC2DecStru32(p,(u32)Battery);
                                p += length;
                                strcpy((char*)p,"%\r\n");
                                p += strlen("V\r\n");
                                pbuff += 7;//命令加1参数
                            break;

                            case 0x13://17字节

                                Co_Sensor_Current_Level = static_cast<unsigned short>(pbuff[3] << 8);
                                Co_Sensor_Current_Level |= pbuff[4];
                                strcpy((char*)p,"Co_Sensor_Current_Level：");
                                p += strlen("Co_Sensor_Current_Level：");
                                length =  DEC2DecStru32(p, Co_Sensor_Current_Level);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");


                                Co_Sensor_Current_Leve_AD = static_cast<unsigned short>(pbuff[5] << 8);
                                Co_Sensor_Current_Leve_AD |= pbuff[6];
                                strcpy((char*)p,"CoLeve_AD：");
                                p += strlen("CoLeve_AD：");
                                length =  DEC2DecStru32(p, Co_Sensor_Current_Leve_AD);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");

                                Gas_Sensor_Current_Level = static_cast<unsigned short>(pbuff[8] << 8);
                                Gas_Sensor_Current_Level |= pbuff[9];
                                strcpy((char*)p,"Gas_Sensor_Current_Level：");
                                p += strlen("Gas_Sensor_Current_Level：");
                                length =  DEC2DecStru32(p, Gas_Sensor_Current_Level);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");


                                Gas_Sensor_Current_Level_AD = static_cast<unsigned short>(pbuff[10] << 8);
                                Gas_Sensor_Current_Level_AD |= pbuff[11];
                                strcpy((char*)p,"Gas_Sensor_Current_Level_AD：");
                                p += strlen("Gas_Sensor_Current_Level_AD：");
                                length =  DEC2DecStru32(p, Gas_Sensor_Current_Level_AD);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");

                                strcpy((char*)p,"temperature：");
                                p += strlen("temperature：");
                                length = DEC2DecStru32(p,pbuff[13]);
                                p += length;
                                strcpy((char*)p,"℃\r\n");
                                p += strlen("℃\r\n");

                                Current_Environment_Light_AD = static_cast<unsigned short>(pbuff[15] << 8);
                                Current_Environment_Light_AD |= pbuff[16];
                                strcpy((char*)p,"Current_Environment_Light_AD：");
                                p += strlen("Current_Environment_Light_AD：");
                                length =  DEC2DecStru32(p, Current_Environment_Light_AD);
                                p += length;
                                strcpy((char*)p,"\r\n");
                                p += strlen("\r\n");


                                pbuff += 17;//命令加1参数
                                break;

              //              case 0x15:
              //                  break;
              //              case 0x1B:
              //                  break;
                            default:
                                pbuff -= (datalength -2);
                                break;
                          }
                        }
                        textedit->setText(QString((char*)out));
                    }
                    if(flashCheckBox->isChecked())//解析底板上传的数据
                    {
                    }
            }//输入长度为偶数
        }
        else{
            textedit->setText("解析框数据为空！！");
        }
    }
    else {
        textedit->setText("选项不是解析的GS875数据！！");
    }
}
