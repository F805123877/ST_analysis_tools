﻿#include "widget.h"
#include <QtWidgets>
#include <QCoreApplication>
#include <QComboBox>
#include <string>
#include <stdio.h>
#include<QAbstractItemView>
#include <QFont>
unsigned char module_type_index = 0;
typedef enum
{
    GS557N,
    GS875N,
    GS524N,
}MODULETYPE;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
/******************创建部件模块**************************/
    textedit = new QTextEdit;
    textedit->setFixedSize(800, 600);//窗口大小
    textedit->setText("data");
    label = new QLabel(tr("Add Data:"));
    lineEdit = new QLineEdit;
    label->setBuddy(lineEdit);//快捷键跳入方框
    ClearButton = new QPushButton(tr("&Clear"));
    AnalyzeButton = new QPushButton(tr("&Analyze"));
    AnalyzeButton->setDefault(true);
    /***************创建可选项**************/
    ChinesePrintBox = new QCheckBox(tr("Chinese Print"));
    outnetinfo = new QCheckBox(tr("show net info"));
    floorCheckBox = new QCheckBox(tr("floor Data"));
    flashCheckBox = new QCheckBox(tr("flash data"));
    uploadCheckBox = new QCheckBox(tr("upload data"));
    uploadCheckBox->setChecked(true);
    /*******************选择模组类型**下拉框**************/
        /**************解析数据类型块*****************/
    ModuleType = new QComboBox();
    ModuleType->setStyleSheet(tr("ModuleType"));
    ModuleType->addItem("GS557N",GS557N);
    ModuleType->addItem("GS875N",GS875N);
    ModuleType->addItem("GS524N",GS524N);
//    ModuleType->setMinimumContentsLength(20);
    ModuleType->setMaximumSize(100,20);
    ModuleType->setStyleSheet("color:red;");
/***************************************************************************************/
    /****************加入可选项和文本框**竖直的************/
        QVBoxLayout *DataTypeLayout = new QVBoxLayout;
        DataTypeLayout->addWidget(floorCheckBox);
        DataTypeLayout->addWidget(uploadCheckBox);
        DataTypeLayout->addWidget(flashCheckBox);
        DataTypeLayout->addWidget(outnetinfo);
    /********************按键模块 解析和清屏**********************/
        buttonBox = new QDialogButtonBox(Qt::Vertical);
        buttonBox->addButton(AnalyzeButton, QDialogButtonBox::ActionRole);
        buttonBox->addButton(ClearButton, QDialogButtonBox::ActionRole);

/*****************模块间的排版***************************/
        /**********提示和输入数据的模块 水平的**************/
        QHBoxLayout *InputDatalayout = new QHBoxLayout;
        InputDatalayout->addWidget(label);//
        InputDatalayout->addWidget(lineEdit);//
        InputDatalayout->addWidget(buttonBox);
//        InputDatalayout->addWidget(ChinesePrintBox);

        /********************模组类型和数据类型并列************************/
        QHBoxLayout *Module_Data_Typelayout = new QHBoxLayout;
        Module_Data_Typelayout->addWidget(ModuleType);
        Module_Data_Typelayout->addLayout(DataTypeLayout);

/*********************信号和槽连接模块*******************************/
    QObject::connect(uploadCheckBox, SIGNAL(stateChanged(int)),this, SLOT(SelectUploadBox()));
    QObject::connect(floorCheckBox, SIGNAL(stateChanged(int)),this, SLOT(SelectFloorBox()));
    QObject::connect(flashCheckBox, SIGNAL(stateChanged(int)),this, SLOT(SelectFlashBox()));
    QObject::connect(ModuleType,SIGNAL(currentIndexChanged(int)),this,SLOT(ModuleTypeChanged()));
//    QObject::connect(AnalyzeButton, SIGNAL(clicked()),this, SLOT(textedit_handle_GS875Ndata()));
//    QObject::connect(AnalyzeButton, SIGNAL(clicked()),this, SLOT(textedit_handle_GS557data()));
    QObject::connect(ClearButton, SIGNAL(clicked()),this, SLOT(Clear_Screen()));

/***********************配置模块位置模块*************************************/
/***********************创建一个主表格*************************************/
    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->setSizeConstraint(QLayout::SetFixedSize);

    mainLayout->addLayout(InputDatalayout, 0, 0);//可选项和文本框的位置
    mainLayout->addLayout(Module_Data_Typelayout,1,0);
    mainLayout->addWidget(textedit, 2, 0);
    mainLayout->setRowStretch(2, 1);//比例划分
    setLayout(mainLayout);//主界面的设置
}

/***********公用函数*******************/
void Widget::SelectUploadBox(void){
    if(uploadCheckBox->isChecked())
    {
        floorCheckBox->setChecked(false);
        flashCheckBox->setChecked(false);
        uploadCheckBox->setChecked(true);
    }

}
void Widget::SelectFloorBox(void)
{
    if(floorCheckBox->isChecked())
    {
        uploadCheckBox->setChecked(false);
        outnetinfo->setChecked(false);
        flashCheckBox->setChecked(false);
        floorCheckBox->setChecked(true);
    }
}

void Widget::SelectFlashBox(void)
{
    if(flashCheckBox->isChecked())
    {
        uploadCheckBox->setChecked(false);
        outnetinfo->setChecked(false);
        flashCheckBox->setChecked(true);
        floorCheckBox->setChecked(false);
    }
}

void Widget::Clear_Screen(void)
{
    textedit->clear();
    lineEdit->clear();
    if(!lineEdit->hasFocus())
    {
        lineEdit->setFocus();
    }
}

void Widget::keyPressEvent(QKeyEvent *event){
    switch (event->key()) {
    case Qt::Key_Return:    //数字键盘的Enter键
    case Qt::Key_Enter:     //Enter键
          AnalyzeButton->click();
    break;
  }
}

void Widget::ModuleTypeChanged(void)
{
    QString currentModuleTypeText = ModuleType->currentText();
    QString  str;
    char*  p;
    QByteArray ba = currentModuleTypeText.toLatin1(); // must
    p=ba.data();
    if(!strcmp(p,"GS557N"))
    {
        module_type_index = 0;
        QObject::connect(AnalyzeButton, SIGNAL(clicked()),this, SLOT(textedit_handle_GS557data()));
    }
    else
    {
        module_type_index = 1;
        QObject::connect(AnalyzeButton, SIGNAL(clicked()),this, SLOT(textedit_handle_GS875Ndata()));
    }
}
