#include "math.h"
#include <string.h>
#include <QString>
typedef unsigned char               u8;
typedef unsigned short              u16;
typedef unsigned int                u32;
typedef signed char                 s8;
typedef signed short                s16;
typedef signed int                  s32;
/********************
*�ַ���ת��16����00003136 ת�� 00 16
*
*********************/
unsigned char str2hex(unsigned char* hexdata,unsigned char* str,unsigned int length){
    if(length%2 == 0){
        //??12F4?????01 02 0F 04
        char data[256] = {0};
        for(unsigned int i=0;i<length;i++){
            if('0'<=str[i]&&str[i]<='9')
            {
                data[i] = (str[i] - '0');
            }
            else if('a'<=str[i]&&str[i]<='f')
            {
                data[i] = (str[i] - 'a' + 10);
            }
            else if('A'<=str[i]&&str[i]<='F')
            {
                data[i] = (str[i] - 'A' + 10);
            }
        }
        for(unsigned int i=0,j=0;i<length;i=i+2,j++){
            hexdata[j] = (char)((data[i]<<4)|(data[i+1]&0x0F));
        }
        return 0;
    }
    else
        return 1;
}
/**********
*??0x08???? ??01?? ????????????????
*****************/
void DEC2Str(unsigned char* p,unsigned char dec){
    if(0<=((dec>>4)&0x0F) && ((dec>>4)&0x0F)<=9){
        p[0] = ((dec>>4)&0x0F) + '0';
    }
    else p[0] = ((dec>>4)&0x0F) + 'A'-10;

    if(0<=(dec&0x0F) && (dec&0x0F)<=9){
         p[1] = (dec&0x0F) + '0';
    }
    else p[1] = (dec&0x0F) + 'A'-10;
}


/**********
*??"F"???? 16
*****************/
unsigned char ASCII2DEC(char dec)
{
	if(('A'<= dec)&&(dec<='F'))
		return (dec-10+'A');
	else if(('a'<= dec)&&(dec<='f'))
		return (dec-10+'a');
	else
		return (dec-'0');
}
/**********
*??8???? '8'
*****************/

unsigned char DEC2ASCII(char dec){
    if((dec>=10) && (dec<=15))
           return (dec-10 +'A');
    else if((dec>=0) && (dec<=9))
            return  (dec + '0');
    else {
       return  0x00;
    }
}

/********************
*??"12"????��?18??   "0012012" -> 0x00 0x00 0x01 0x02 0x00 0x01 0x02 -> "73746"
*??16?????????????10?????????
*length?????????????
*******************/
unsigned char HexStr2DecStr(unsigned char* p1,unsigned char* HexStr,unsigned char length)
{
    char negative_flag = 0;
    unsigned int sum = 0,temp_sum = 0;
    unsigned int muti = 1;
    unsigned char i = 0, j = 0;
//�жϷ���
    if(p1[0]&0x80)
    {
        negative_flag = 1;
    }
    //������ֵ
    for(i=0; i<length; i++)
    {
        muti = 1;
        for(j=0; j<i; j++)
        {
            muti *= 256;
        }
        sum += muti * HexStr[length-i-1];
    }

    temp_sum = sum;
    length = 0;
    //����λ��
    for (length=1;temp_sum/10>0;length++) {
        temp_sum /= 10;
    }
//ת����ASCII
    for (i=0;i<length;i++)
    {
        *(p1+length-i-1) = DEC2ASCII(sum%10);
        sum /= 10;
    }
    return length;
}

unsigned char DEC2DecStru32(unsigned char* pstr, u32 decdata )
{
    u32 temp_sum = decdata;
    unsigned char length = 0,i=0;
    //����λ��
    for (length=1;temp_sum/10>0;length++) {
        temp_sum /= 10;
    }
//ת����ASCII
    for (i=0;i<length;i++)
    {
        *(pstr+length-i-1) = DEC2ASCII(decdata%10);
        decdata /= 10;
    }
    return length;
}

unsigned char DEC2DecStrs16(unsigned char* pstr, u16 decdata )
{
    unsigned char negative_flag = 0;
    u16 temp_sum = decdata;
    u16 temp_sum1;
    unsigned char length = 0,i=0;
    unsigned char*p = pstr;
    //�жϷ���
    if(temp_sum&0x8000)
    {
        negative_flag = 1;
        temp_sum = ~decdata + 1;//ת��������
    }
    else
    {
        temp_sum = decdata;
        negative_flag = 0;
    }
    temp_sum1 = temp_sum;

    //����λ��
    for (length=1;temp_sum/10>0;length++) {
        temp_sum /= 10;
    }
//ת����ASCII
    if(negative_flag == 1)
    {
        *(p++) = '-';
    }
    for (i=0;i<length;i++)
    {
        *(p+length-i-1) = DEC2ASCII(temp_sum1%10);
        temp_sum1 /= 10;
    }
    if(negative_flag == 1)
    {
        return length+1;
    }
    else
    {
        return length;
    }
}
/****************
*??????16????????hexData  ????????hexLength
*?????????edcData ?????????????edcLength
**************/

void HEX2EDCStr(char* hexData,unsigned char hexLength,char* edcData,unsigned char edcLength)
{
    int i = 0;
    unsigned int temp = 0;
    unsigned int data = 0;
    //??????????????
    for (i=0; i<hexLength; i++)
    {
        data = data << 8;
        data |= static_cast<unsigned int>(hexData[i]);
    }
    temp = data;
//    for(int i=0; i<hexLength-1; i++)
//    {
//        edcData += hexData[i] * pow(256,hexLength-i-1);
//    }
    for(int i=0;i<10;i++)
    {
        if(data%10 != 0)
        {
//           DEC2ASCII(edcData[i],(data%10));
           edcLength += 1;
           data /= 10;
        }
        else
        {
            break;
        }
    }
    for(i=0;i<edcLength;i++)
    {
        edcData[edcLength-i-1] = DEC2ASCII(temp%10);
        temp /= 10;
    }

}

void String_ASCII_to_Hex(u8 *data, const u8 string)
{
    if ((string >= '0') && (string <= '9'))
    {
        *data = string - '0';
    }
    else if ((string >= 'A') && (string <= 'F'))
    {
        *data = string - 'A' + 10;
    }
    else if ((string >= 'a') && (string <= 'f'))
    {
        *data = string - 'a' + 10;
    }
    else
    {
        *data = 0;
    }
}

void String_ASCIIArray_to_HexArray(u8 *data, u8 *data1, u16 length)
{
    u16 i;
    u8 d, y;

    for (i = 0; i < length; i++)
    {
        String_ASCII_to_Hex(&y, *(data1 + (i*2)));
        d = (y << 4) & 0xf0;

        String_ASCII_to_Hex(&y, *(data1 + (i*2) + 1));
        *(data + i) = d | (y & 0x0f);
    }
}

//void DisplayTime(u8 *buff)
//{
//    u32 year, mon, day, hour, min, sec;
//    year = *(buff + 0);
//    mon = *(buff + 1);
//    day = *(buff + 2);
//    hour = *(buff + 3);
//    min = *(buff + 4);
//    sec = *(buff + 5);
//}

u8 distext(unsigned char* buff, const char* str)
{
    char temp[256] = {0};
    strcpy((char*)temp, (char*)str);
    strcat(temp,"\r\n");
    strcpy((char*)buff,(char*)temp);
    return static_cast<u8>(strlen(temp));
}

u8 distextDirect(unsigned char* buff, const char* str)
{
    char temp[256] = {0};
    strcpy((char*)temp, (char*)str);
    strcpy((char*)buff,(char*)temp);
    return static_cast<u8>(strlen(temp));
}

/**********
*??0xef ->"239"
*****************/
u8 hex2DECstr(unsigned char* p, u32 hexdata)
{
    u32 temp,muti = 1;
    u8 length = 1,negative_flag = 0;
    u8 i = 0;
    temp = hexdata;
    if(hexdata&0x80)
    {
     negative_flag = 1;
    }
    while(temp/10)
    {
        length++;
        temp %= 10;
    }
    for(i=1;i<length;i++)
    {
        muti *= 10;
    }
    if(negative_flag == 1)
     {
         length++;
         *(p++) = '-';
     }
    temp = hexdata;
    for(i=0;i<length;i++)
    {
        p[i] = DEC2ASCII((unsigned char)temp/muti);
        muti /= 10;
        temp /= 10;
    }
    return length;
}

QString decToBin(unsigned int nDec)
{
    int nYushu, nShang;
    QString strBin, strTemp;
    //TCHAR buf[2];
    bool bContinue = true;
    while ( bContinue )
    {
        nYushu = nDec % 2;
        nShang = nDec / 2;
        strBin=QString::number(nYushu)+strBin; //qDebug()<<strBin;
        strTemp = strBin;
        //strBin.Format("%s%s", buf, strTemp);
        nDec = nShang;
        if ( nShang == 0 )
            bContinue = false;
    }
    int nTemp = strBin.length() % 8;
    switch(nTemp)
    {
    case 1:
        //strTemp.Format(_T("000%s"), strBin);
        strTemp = "0000000"+strBin;
        strBin = strTemp;
        break;
    case 2:
        //strTemp.Format(_T("00%s"), strBin);
        strTemp = "000000"+strBin;
        strBin = strTemp;
        break;
    case 3:
        //strTemp.Format(_T("0%s"), strBin);
        strTemp = "00000"+strBin;
        strBin = strTemp;
        break;
    case 4:
        strTemp = "0000"+strBin;
        strBin = strTemp;
        break;
    case 5:
        strTemp = "000"+strBin;
        strBin = strTemp;
        break;
    case 6:
        strTemp = "00"+strBin;
        strBin = strTemp;
        break;
    case 7:
        strTemp = "0"+strBin;
        strBin = strTemp;
        break;
    default:
        break;
    }
    return strBin;
}
/********************
*16���ư��ֽ� ���������
*
*FF55200201 0F 05FF 80 0300 13100200000000030000022D04160600C7 11A50A0DDD17
*******************/
unsigned char Hex2BinaryStr(unsigned char* BinaryStr,unsigned char HexData)
{
    unsigned char* p = BinaryStr;
    char i = 0;
    unsigned char b = 0;
    for(i=7;i>=0;i--)
    {
        b = (HexData>>i)&0x01;
        *(p++) = DEC2ASCII(b);
    }
    return 8;
}
