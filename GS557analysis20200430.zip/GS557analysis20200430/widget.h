﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QLabel>
#include <QDialogButtonBox>
#include <QComboBox>

//QT_BEGIN_NAMESPACE
//class QCheckBox;
//class QDialogButtonBox;
//class QGroupBox;
//class QLabel;
//class QLineEdit;
//class QPushButton;
//class QTextEdit;
//QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:

    Widget(QWidget *parent = 0);

//private:
    QTextEdit *textedit;
    QLabel *label;
    QLineEdit *lineEdit;
    QCheckBox *outnetinfo;
    QCheckBox *floorCheckBox;
    QCheckBox *uploadCheckBox;
    QCheckBox *flashCheckBox;

    QComboBox *ModuleType;

//    QCheckBox *GS875NCheckBox;
//    QCheckBox *GS557CheckBox;
    QCheckBox *ChinesePrintBox;
    QCheckBox *wholeWordsCheckBox;
    QCheckBox *searchSelectionCheckBox;
    QCheckBox *backwardCheckBox;
    QDialogButtonBox *buttonBox;
    QPushButton *AnalyzeButton;
    QPushButton *ClearButton;
    QWidget *extension;


private:

private slots:
void textedit_handle_GS557data(void);
void textedit_handle_GS875Ndata(void);
void SelectUploadBox(void);
void SelectFloorBox(void);
void SelectFlashBox(void);
//void SelectDevice(void);
void Clear_Screen(void);
void keyPressEvent(QKeyEvent *event);
void ModuleTypeChanged(void);
};

#endif // WIDGET_H
