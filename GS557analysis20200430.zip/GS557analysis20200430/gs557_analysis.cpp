﻿#include "widget.h"
#include <QtWidgets>
#include "my_string.h"
#include <string.h>
#include <QTextCodec>
#include <iostream>
using namespace std;

typedef unsigned char               u8;
typedef unsigned short              u16;
typedef unsigned int                u32;
typedef signed char                 s8;
typedef signed short                s16;
typedef signed int                  s32;

void Widget::textedit_handle_GS557data(void){
    if(module_type_index == 0)
    {
        unsigned int start = 0, end = 0;
        unsigned char length = 0;
        unsigned short temp_num = 0;
        textedit->clear();
        char result = 0;
//        unsigned char tempLength = 0;
        unsigned char datalength = 0;
        char* pdata1 = lineEdit->text().toLocal8Bit().data();
        unsigned char* pdata = (unsigned char*)pdata1;
        unsigned char buff[256];

        unsigned char out[1024] = {0};
        unsigned char *p = out;
        unsigned char *pbuff = buff;
        if(strlen((char*)pdata) > 0)
        {
            result = str2hex(buff,pdata,strlen((char*)pdata));//60  //0x12  0x01 0x02
            if(result)
                textedit->setText("输入待解析的数据长度不为偶数！！");
            else{

                if(uploadCheckBox->isChecked())//解析上传到平台的数据
                {
//                    //判断长度
//                    length = distextDirect(p, "Length ：");
//                    p += length;
//                    temp_num = (buff[0]&0xFF)<<8;
//                    temp_num |= (buff[1]&0xFF);
//                    length = DEC2DecStru32(p,temp_num);
//                    p += length;
//                    strcpy((char*)p,"\r\n");
//                    p += strlen("\r\n");

//                    if(temp_num != strlen((char*)buff))
//                    {
//                        length = distextDirect(p, "The data length is error!");
//                        p += length;
//                    }
//                    //option
//                    length = distextDirect(p, "Option ：");
//                    p += length;
//                    length = DEC2DecStru32(p,buff[2]);
//                    p += length;

//                    //Serial
//                    length = distextDirect(p, "Serial ：");
//                    p += length;
//                    temp_num = (buff[3]&0xFF)<<8;
//                    temp_num |= (buff[4]&0xFF);
//                    length = DEC2DecStru32(p,temp_num);
//                    p += length;

                        if(buff[0] == 0x00)
                        {
                            length =  distext(p, "非注册包");
                            p += length;
                        }
                //公共状态
                        if(buff[1]&0x80)
                        {
                            length =  distext(p, "触发防拆报警");
                            p += length;
                        }
                        if(buff[1]&0x40)
                        {
                            length =  distext(p, "蜂鸣器故障");
                            p += length;
                        }
                        if(buff[1]&0x20)
                        {
                            length =  distext(p, "寿命终止");
                            p += length;
                        }
                        if(buff[1]&0x10)
                        {
                            length =  distext(p, "低压");
                            p += length;
                        }
                        if(buff[1]&0x08)
                        {
                            length =  distext(p, "低压免打扰");
                            p += length;
                        }
                        if(buff[1]&0x04)
                        {
                            length =  distext(p, "与底板通讯异常");
                            p += length;
                        }
                        if(buff[1]&0x02)
                        {
                            length =  distext(p, "本地报警测试");
                            p += length;
                        }
                        if(buff[1]&0x01)
                        {
                            length =  distext(p, "心跳包");
                            p += length;
                        }
                //烟感状态
                        if(buff[2]&0x80)
                        {
                            length =  distext(p, "烟雾预警");
                            p += length;
                        }
                        if(buff[2]&0x40)
                        {
                            length =  distext(p, "烟雾报警");
                            p += length;
                        }
                        if(buff[2]&0x20)
                        {
                            length =  distext(p, "烟雾报警静音");
                            p += length;
                        }
                        if(buff[2]&0x10)
                        {
                            length =  distext(p, "烟雾传感器故障");
                            p += length;
                        }
                        if(buff[2]&0x08)
                        {
                            length =  distext(p, "烟雾传感器故障免打扰");
                            p += length;
                        }

                //电量
                        length = distextDirect(p, "电量为：");
                        p += length;
                        DEC2Str(p,buff[3]);
                        p += 2;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");
                //烟雾浓度
                        length = distextDirect(p, "烟雾浓度为：");
                        p += length;
                        length = DEC2DecStru32(p, buff[4]);
                        p += length;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");

                        length = distextDirect(p, "R烟雾浓度为：");
                        p += length;
                        length = DEC2DecStru32(p, buff[5]);
                        p += length;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");
                //温度
                        strcpy((char*)p,"温度为：");
                        p += strlen("温度为：");
                        length = DEC2DecStrs16(p, buff[6]);
                        p += length;
                        strcpy((char*)p,"\r\n");
                        p += strlen("\r\n");
                if(outnetinfo->isChecked()){
                //RSRP 有符号
                    strcpy((char*)p,"RSRP：");
                    p += strlen("RSRP：");
                    temp_num = (buff[7]&0xFF)<<8;
                    temp_num |= (buff[8]&0xFF);
                    length = DEC2DecStrs16(p,temp_num);
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //CSQ
                    strcpy((char*)p,"CSQ：");
                    p += strlen("CSQ：");
                    length = DEC2DecStru32(p,buff[9]);
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //SNR 有符号
                    strcpy((char*)p,"SNR：");
                    p += strlen("SNR：");
                    temp_num = (buff[10]&0xFF)<<8;
                    temp_num |= (buff[11]&0xFF);
                    length = DEC2DecStrs16(p,temp_num );
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //PCI
                    strcpy((char*)p,"PCI：");
                    p += strlen("PCI：");
                    temp_num = (buff[12]&0xFF)<<8;
                    temp_num |= (buff[13]&0xFF);
                    length = DEC2DecStru32(p,temp_num);
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //ECL
                    strcpy((char*)p,"ECL：");
                    p += strlen("ECL：");
                    DEC2Str(p,buff[14]); //12    31 32
                    p += 2;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //RSRP 有符号
                    strcpy((char*)p,"RSRQ：");
                    p += strlen("RSRP：");
                    temp_num = (u16)((buff[15]&0xFF)<<8);
                    temp_num |= (u16)(buff[16]&0xFF);
                    length = DEC2DecStrs16(p,temp_num );
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //EARFCN
                    strcpy((char*)p,"频点为：");
                    p += strlen("频点为：");
                    start = (start << 8) | buff[17];
                    start = (start << 8) | buff[18];
                    start = (start << 8) | buff[19];
                    start = (start << 8) | buff[20];
                    length = DEC2DecStru32(p,start);
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                //小区
                    strcpy((char*)p,"小区号为：");
                    p += strlen("小区号为：");
                    start = (start << 8) | buff[21];
                    start = (start << 8) | buff[22];
                    start = (start << 8) | buff[23];
                    start = (start << 8) | buff[24];
                    length = DEC2DecStru32(p,start);
                    p += length;
                    strcpy((char*)p,"\r\n");
                    p += strlen("\r\n");
                    }
                }
              if(floorCheckBox->isChecked())//解析底板上传的数据
              {
                  //硬件版本
                  //FF551501 01
                  datalength = pbuff[2];
                  pbuff += 4;
                  while(*pbuff)
                  {
                      switch (*pbuff){
                      case 0x01:
                          strcpy((char*)p,"应答成功\r\n");
                          p += strlen("应答成功\r\n");
                          pbuff += 1;//命令没有参数
                          break;
                      case 0x05://1字节
                              strcpy((char*)p,"硬件版本号为：");
                              p += strlen("硬件版本号为：");
                              DEC2Str(p,pbuff[1]);
                              p += 2;
                              strcpy((char*)p,"\r\n");
                              p += strlen("\r\n");
                              pbuff += 2;//命令加1参数
                          break;
                      case 0x0F://5字节
                              if(pbuff[3]&0x80){
                                  strcpy((char*)p,"触发防拆报警\r\n");
                                  p += strlen("触发防拆报警\r\n");
                              }
                              if(pbuff[3]&0x40){
                                  strcpy((char*)p,"蜂鸣器故障\r\n");
                                  p += strlen("蜂鸣器故障\r\n");
                              }
                              if(pbuff[3]&0x20){
                                  strcpy((char*)p,"寿命终止\r\n");
                                  p += strlen("寿命终止\r\n");
                              }
                              if(pbuff[3]&0x10){
                                  strcpy((char*)p,"低压报警\r\n");
                                  p += strlen("低压报警\r\n");
                              }
                              if(pbuff[3]&0x08){
                                  strcpy((char*)p,"低压报警免打扰\r\n");
                                  p += strlen("低压报警免打扰\r\n");
                              }
                              if(pbuff[3]&0x04){
                                  strcpy((char*)p,"与底板通讯异常\r\n");
                                  p += strlen("与底板通讯异常\r\n");
                              }
                              if(pbuff[3]&0x02){
                                  strcpy((char*)p,"本地报警测试\r\n");
                                  p += strlen("本地报警测试\r\n");
                              }
                              if(pbuff[3]&0x01){
                                  strcpy((char*)p,"心跳包\r\n");
                                  p += strlen("心跳包\r\n");
                              }
                              if(pbuff[5]&0x80){
                                  strcpy((char*)p,"烟雾预警\r\n");
                                  p += strlen("烟雾预警\r\n");
                              }
                              if(pbuff[5]&0x40){
                                  strcpy((char*)p,"烟雾报警\r\n");
                                  p += strlen("烟雾报警\r\n");
                              }
                              if(pbuff[5]&0x20){
                                  strcpy((char*)p,"烟雾报警静音\r\n");
                                  p += strlen("烟雾报警静音\r\n");
                              }
                              if(pbuff[5]&0x10){
                                  strcpy((char*)p,"烟雾传感器故障\r\n");
                                  p += strlen("烟雾传感器故障\r\n");
                              }
                              if(pbuff[5]&0x08){
                                  strcpy((char*)p,"烟雾传感器故障免打扰\r\n");
                                  p += strlen("烟雾传感器故障免打扰\r\n");
                              }
                              pbuff += 6;//命令加5参数
                          break;
                      case 0x11://6字节
                          strcpy((char*)p,"电量为：");
                          p += strlen("电量为：");
                          length = DEC2DecStru32(p,pbuff[6]);
                          p += length;
//                          DEC2Str(p,pbuff[6]);
//                          p += 2;
                          strcpy((char*)p,"\r\n");
                          p += strlen("\r\n");
                          pbuff += 7;//命令加1参数
                          break;
                      case 0x13://20字节
                          strcpy((char*)p,"烟雾浓度1为：");
                          p += strlen("烟雾浓度1为：");
                          length = DEC2DecStru32(p,pbuff[3]);
                          p += length;
                          strcpy((char*)p,"\r\n");
                          p += strlen("\r\n");

                          strcpy((char*)p,"烟雾浓度2为：");
                          p += strlen("烟雾浓度2为：");
                          length = DEC2DecStru32(p,pbuff[4]);
                          p += length;
                          strcpy((char*)p,"\r\n");
                          p += strlen("\r\n");

                          strcpy((char*)p,"温度为：");
                          p += strlen("温度为：");
                          length = DEC2DecStru32(p,pbuff[20]);
                          p += length;
                          strcpy((char*)p,"\r\n");
                          p += strlen("\r\n");
                          pbuff += 21;//命令加1参数
                          break;
        //              case 0x15:
        //                  break;
        //              case 0x1B:
        //                  break;
                      default:
                          pbuff -= (datalength -2);
                          break;
                    }
                  }
              }
              if(flashCheckBox->isChecked())//解析底板上传的数据
              {
//                  if(strlen(buff) != 56)
//                  {
//                      textedit->setText("输入数据的长度不对！！");
//                  }
                  if (buff[0] > 1)
                  {
                      length =  distext(p, "单次设置未完成");
                      p += length;
                  }

                  if (buff[1] == 0)
                  {
                      length =  distext(p, "单次设置未完成");
                      p += length;
                  }
                  if (buff[1] == 1)
                  {
                      length =  distext(p, "单次设置已完成");
                      p += length;
                  }

                  if (!buff[1])
                  {
                      length =  distext(p, static_cast<const char*>("注册消息未成功上传"));
                      p += length;
                  }
                  else
                  {
                      length =  distext(p, "注册消息已成功上传");
                      p += length;
                  }

                  if ((buff[2] != 0x00) && (buff[2] != 0x55) && ((u8)buff[2] != 0xaa))
                  {
                      length =  distext(p, "入网离散标志不在枚举范围内！！");
                      p += length;
                  }
                      if (buff[2] == 0x00)
                      {
                          length =  distext(p, "入网离散未开始");
                          p += length;
                      }
                      else if (buff[2] == 0x55)
                      {
                          length =  distext(p, "入网离散进行中");
                          p += length;
                      }
                      else
                      {
                          length =  distext(p, "入网离散已完成");
                          p += length;
                      }

                      if ((buff[3] != 0x00) && (buff[3] != 0x55) && ((u8)buff[3] != 0xaa))
                      {
                          length =  distext(p, "心跳离散标志不在枚举范围内！！");
                          p += length;
                      }
                          if (buff[3] == 0x00)
                          {
                              length =  distext(p, "心跳离散未开始");
                              p += length;
                          }
                          else if (buff[3] == 0x55)
                          {
                              length =  distext(p, "心跳离散进行中");
                              p += length;
                          }
                          else
                          {
                              length =  distext(p, "心跳离散已完成");
                              p += length;
                          }

                          if ((buff[4] != 0x00) && (buff[4] != 0x55) && ((u8)buff[4] != 0xaa))
                          {
                              length =  distext(p, "心跳定时器标志不在枚举范围内！！");
                              p += length;
                          }

                              if (buff[4] == 0x00)
                              {
                                  length =  distext(p, "心跳定时器未创建");
                                  p += length;
                              }
                              else if (buff[4] == 0x55)
                              {
                                  length =  distext(p, "心跳定时器已开启");
                                  p += length;
                              }
                              else
                              {
                                  length =  distext(p, "心跳定时器已停止");
                                  p += length;
                              }

                              start = buff[9]&0xFF;
                              start <<= 8;
                              start |= buff[10]&0xFF;
                              start <<= 8;
                              start |= buff[11]&0xFF;
                              start <<= 8;
                              start |= buff[12]&0xFF;

                              end = buff[13]&0xFF;
                              end <<= 8;
                              end |= buff[14]&0xFF;
                              end <<= 8;
                              end |= buff[15]&0xFF;
                              end <<= 8;
                              end |= buff[16]&0xFF;

                              if (start <= end)
                              {
                                  start = end - start;
                              }
                              else
                              {
                                  start = 0xffffffff - start + end + 1;
                              }

                              start /= 100;
                              length = distextDirect(p, "RTC定时器的超时时间为：");
                              p += length;
                              length = DEC2DecStru32(p, start);
                              p += length;


                              start = buff[17]&0xFF;
                              start <<= 8;
                              start |= buff[18]&0xFF;
                              start <<= 8;
                              start |= buff[19]&0xFF;
                              start <<= 8;
                              start |= buff[20]&0xFF;

                              start /= 100;
                              length = distextDirect(p, "\n上次剩余RTC时间为：");
                              p += length;
                              length = DEC2DecStru32(p, start);
                              p += length;

//                              length = HexStr2DecStr(p,&buff[17],4);
//                              p += (length-2);//省去小数点


                              start = buff[21]&0xFF;
                              length = distextDirect(p, "\n心跳计数值为：");
                              p += length;
                              length = DEC2DecStru32(p, start);
                              p += length;

                              if (buff[22] > 1)
                              {
                                  length =  distextDirect(p, "\n不在心跳枚举范围内！！");
                                  p += length;
                              }
                                  if (buff[22] == 0)
                                  {
                                      length =  distextDirect(p, "\n下次执行重启时，无需作为心跳");
                                      p += length;
                                  }
                                  else
                                  {
                                      length =  distextDirect(p, "\n下次执行重启时，需要作为心跳");
                                      p += length;
                                  }


                              if (buff[23] > 1)
                              {
                                  length =  distextDirect(p, "\n不在本地执行过测试的标志枚举范围内！！\n");
                                  p += length;
                              }
                              else
                              {
                                  if (buff[23] == 0)
                                  {
                                      length =  distextDirect(p, "\n下次执行重启时，无需标记收到过本地测试\n");
                                      p += length;
                                  }
                                  else
                                  {
                                      length =  distextDirect(p, "\n下次执行重启时，需要标记收到过本地测试\n");
                                      p += length;
                                  }
                              }

//                              DEC2Str(p,pbuff[24]);
//                              p += 2;
                              length = DEC2DecStru32(p, pbuff[24]);
                              p += length;
                              length = distextDirect(p, "/");
                              p += length;
//                              DEC2Str(p,pbuff[25]);
//                              p += 2;
                              length = DEC2DecStru32(p, pbuff[25]);
                              p += length;
                              length = distextDirect(p, "/");
                              p += length;
//                              DEC2Str(p,pbuff[26]);
//                              p += 2;
                              length = DEC2DecStru32(p, pbuff[26]);
                              p += length;
                              length = distextDirect(p, ", ");
                              p += length;
//                              DEC2Str(p,pbuff[27]);
//                              p += 2;
                              length = DEC2DecStru32(p, pbuff[27]);
                              p += length;
                              length = distextDirect(p, ":");
                              p += length;
                              length = DEC2DecStru32(p, pbuff[28]);
                              p += length;
                              length = distextDirect(p, ":");
                              p += length;
                              length = DEC2DecStru32(p, pbuff[29]);
                              p += length;

                              length = distextDirect(p, "\n流水号为：");
                              p += length;
                              temp_num = (u16)((buff[15]&0xFF)<<8);
                              temp_num |= (u16)(buff[16]&0xFF);
                              length = DEC2DecStru32(p, temp_num);
                              p += length;

                              strcpy((char*)p,"\r\n");
                              p += strlen("\r\n");
              }
            }
            textedit->setText(QString((char*)out));
        }
        else{
            textedit->setText("解析框数据为空！！");
        }
    }
    else {
        textedit->setText("选项不是解析的GS557数据！！");
    }
}
