﻿#ifndef MY_STRING_H
#define MY_STRING_H
#include <QString>
typedef unsigned char               u8;
typedef unsigned int                u32;
typedef unsigned short              u16;
extern unsigned char module_type_index;
void HEX2EDCStr(unsigned char* hexData,unsigned char hexLength,unsigned char* edcData,unsigned char edcLength);
unsigned char str2hex(unsigned char* hexdata,unsigned char* str,unsigned int length);
u8 distext(unsigned char* buff, const char* str);
u8 distextDirect(unsigned char* buff, const char* str);
void DEC2Str(unsigned char* p,unsigned char dec);
unsigned char ASCII2DEC(unsigned char dec);
unsigned char DEC2ASCII(unsigned char dec);
unsigned char HexStr2DecStr(unsigned char* p1,unsigned char* HexStr,unsigned char length);
u8 hex2DECstr(unsigned char* p, u32 hexdata);
unsigned char DEC2DecStru32(unsigned char* pstr, u32 decdata );
unsigned char DEC2DecStrs16(unsigned char* pstr, u16 decdata );
unsigned char Hex2BinaryStr(unsigned char* BinaryStr,unsigned char HexData);
QString decToBin(unsigned int nDec);
#endif // MY_STRING_H
